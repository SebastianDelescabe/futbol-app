import { SelectTeam } from '@/components/home/SelectTeam'

export default function Home() {

  return (
    <div id='home'>
      <SelectTeam />
    </div>
  )
}
