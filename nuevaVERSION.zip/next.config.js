/** @type {import('next').NextConfig} */
const nextConfig = {
    experimental: {
        css: true,
        appDir: true
    }
}

module.exports = nextConfig
