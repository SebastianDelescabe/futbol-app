export const LiveMatchs = () => {
    return (
        <div id="liveMatchs">
            <div className="liveMatchs__container">
                <span>PARTIDOS EN VIVO</span>
            </div>
        </div>
    )
}