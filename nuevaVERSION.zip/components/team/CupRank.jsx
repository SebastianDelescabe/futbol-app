export const CupRank = ({ data }) => {
    console.log(data, 'cupRank');
    let { competitionData, allCompetitions } = data

    return (
        <div id="cupRank">
            <div>ACAAA</div>
        </div>
    );
}


